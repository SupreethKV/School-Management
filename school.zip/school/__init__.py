# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module for School Management System
# ----------------------------------------------------------

from . import models
from . import wizard
